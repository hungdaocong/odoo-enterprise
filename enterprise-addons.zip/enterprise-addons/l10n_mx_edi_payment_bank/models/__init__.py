# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_bank_statement
from . import account_payment
from . import res_bank
