# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_inter_company_so_to_po
from . import test_inter_company_po_to_so
from . import test_inter_company_invoice
