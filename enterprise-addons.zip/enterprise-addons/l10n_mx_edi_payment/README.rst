EDI Payment
===========

This payment module for Mexican Localization allows satisfying the SAT indication
which established that a payment complement can be emitted ten (10) days after,
of the same month, when was received.
