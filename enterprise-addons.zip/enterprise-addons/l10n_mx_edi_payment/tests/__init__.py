from . import test_l10n_mx_edi_payment
